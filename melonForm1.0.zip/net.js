﻿//.net code with js

Text="MelonForm";
Width=990;
Height=700;
MaximizeBox=false;

netApi.getTime=function(){
	return System.DateTime.Now.ToString('yyyy-MM-dd hh:mm:ss');
}

netApi.getHostName=function(){
	return System.Net.Dns.GetHostName().ToString();
}