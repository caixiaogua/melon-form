using System;
using System.Windows.Forms;
using Microsoft.CSharp;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Reflection;
// using System.Runtime.InteropServices;
class Link {
    public static MethodInfo to(string dn, string fn)
    {
        string cn="Linker";
        string cstr=@"
            public class "+cn+@"
            {
                [System.Runtime.InteropServices.DllImport("""+dn+@""", CallingConvention=System.Runtime.InteropServices.CallingConvention.Cdecl)]
                public static extern "+fn+@";
            }
        ";
        // Console.WriteLine(cstr);
        CSharpCodeProvider objCSharpCodePrivoder = new CSharpCodeProvider();
        CompilerParameters objCompilerParameters = new CompilerParameters();

        // objCompilerParameters.ReferencedAssemblies.Add("System.dll");
        // objCompilerParameters.ReferencedAssemblies.Add("System.Runtime.InteropServices");

        objCompilerParameters.GenerateExecutable = false;
        objCompilerParameters.GenerateInMemory = true;

        CompilerResults cresult = objCSharpCodePrivoder.CompileAssemblyFromSource(objCompilerParameters, cstr);

        if (cresult.Errors.HasErrors)
        {
        foreach (CompilerError err in cresult.Errors)
        {
            MessageBox.Show(err.ErrorText);
        }
        return null;
        }
        else
        {
        // 通过反射，执行代码
        Assembly objAssembly = cresult.CompiledAssembly;
        // object obj = objAssembly.CreateInstance("CodeTest.Test");
        // MethodInfo objMI = obj.GetType().GetMethod("ShowMessage");
        // objMI.Invoke(obj, new object[] { "This is CodeTest!" });
        return objAssembly.GetType(cn).GetMethods()[0];
        }
    }
}