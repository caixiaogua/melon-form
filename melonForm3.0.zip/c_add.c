#include <stdio.h>

int add(int a, int b){
	int c=a+b;
	printf("sum: %d\n", c);
	return c;
}