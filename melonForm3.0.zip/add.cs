using System;

public class addclass
{
	public static Int32 add(Int32 i, Int32 j)
	{
		return i + j;
	}
}
