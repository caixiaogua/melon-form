﻿//.net code with js

Text="MelonForm v2.1";
Width=990;
Height=600;
MaximizeBox=false;

// browser.Visible=false;
// var a=new Button();
// a.Text="Click Me";
// Controls.Add(a);

// webApi为webform浏览器函数集，上下文环境为window

webApi.main=function(){
	window.external.netApi.init();
	// alert("Are you OK?");
	document.write("<h2>WebForm初始化完成</h2>");
}

// netApi为dotnet框架接口函数集，上下文环境为.net framework或netcore

netApi.init=function(){
	browser.Document.Write("正在载入......");
	// browser.Navigate(Application.StartupPath + "/main.htm");
	// browser.Navigate("https://cn.bing.com/");
}

netApi.getTime=function(){
	return System.DateTime.Now.ToString('yyyy-MM-dd hh:mm:ss');
}

netApi.getHostName=function(){
	return System.Net.Dns.GetHostName().ToString();
}

netApi.readFile=function(f){
	try{
		var s=System.IO.File.ReadAllText(f);
		return s;
	}catch(e){
		MessageBox.Show(e);
	}
}

netApi.saveFile=function(f,s){
	try{
	    var fs=new System.IO.FileStream(f,System.IO.FileMode.Create);	/*打开文件流*/
	    var sw=new System.IO.StreamWriter(fs,System.Text.Encoding.Default);		/*创建读写器*/
	    sw.Write(s);	/*读写*/
	    sw.Close();		/*关闭读写器*/
	    fs.Close();		/*关闭文件流*/
		return true;
	}catch(e){
		MessageBox.Show(e);
	}
}